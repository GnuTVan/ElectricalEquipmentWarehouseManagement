https://shreethemes.in/doctris/layouts/admin/index.html
https://shreethemes.in/doctris/layouts/landing/index.html