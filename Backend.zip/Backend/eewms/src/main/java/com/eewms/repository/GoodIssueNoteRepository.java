package com.eewms.repository;

import com.eewms.entities.GoodIssueNote;
import org.springframework.data.jpa.repository.JpaRepository;

public interface GoodIssueNoteRepository extends JpaRepository<GoodIssueNote, Long> {
}
