package com.eewms.services;

import org.springframework.web.multipart.MultipartFile;

public interface ImageUploadService {
    String uploadImage(MultipartFile file);

    void deleteImageByUrl(String imageUrl);
}
