package com.eewms.constant;

public enum Role {
    ADMIN,
    MANAGER,
    STAFF
}
