package com.eewms.dto.vietQR;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class VietqrBankItem {
    private String code, name, shortName, bin, logo;
}
