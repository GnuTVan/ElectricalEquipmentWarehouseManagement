package com.eewms.constant;

public enum RoleEnum {
    STAFF,
    ADMIN
}
