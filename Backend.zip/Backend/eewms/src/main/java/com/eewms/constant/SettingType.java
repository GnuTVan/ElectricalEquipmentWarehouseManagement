// src/main/java/com/eewms/constant/SettingType.java
package com.eewms.constant;

public enum SettingType {
    UNIT,
    CATEGORY,
    BRAND
}
