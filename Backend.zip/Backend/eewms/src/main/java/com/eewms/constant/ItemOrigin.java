package com.eewms.constant;

public enum ItemOrigin {
    MANUAL,
    COMBO
}
