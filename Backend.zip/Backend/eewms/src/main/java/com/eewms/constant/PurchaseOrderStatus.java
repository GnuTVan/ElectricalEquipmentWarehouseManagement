package com.eewms.constant;

public enum PurchaseOrderStatus {
    CHO_GIAO_HANG,      // Chờ giao hàng
    DA_GIAO_MOT_PHAN,   // Đã giao một phần
    HOAN_THANH,         // Hoàn thành
    HUY                 // Đã huỷ
}