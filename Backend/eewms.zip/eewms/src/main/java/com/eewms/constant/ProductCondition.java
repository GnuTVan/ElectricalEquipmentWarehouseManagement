package com.eewms.constant;

public enum ProductCondition {
    NEW,        // hàng bình thường
    RETURNED    // hàng hoàn về (cũ)
}