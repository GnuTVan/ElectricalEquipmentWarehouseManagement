package com.eewms.repository.inventoryTransfer;

import com.eewms.entities.InventoryTransfer;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;

public interface InventoryTransferRepository extends JpaRepository<InventoryTransfer, Long> {

    boolean existsByCode(String code);

    @EntityGraph(attributePaths = {"fromWarehouse", "toWarehouse", "createdBy"})
    @Query("""
        select t from InventoryTransfer t
        where (:keyword is null or :keyword = ''
               or lower(t.code) like lower(concat('%', :keyword, '%'))
               or lower(t.note) like lower(concat('%', :keyword, '%')))
          and (:status is null or t.status = :status)
          and (:fromDate is null or t.createdAt >= :fromDate)
          and (:toDate   is null or t.createdAt <= :toDate)
          and (:fromWarehouseId is null or t.fromWarehouse.id = :fromWarehouseId)
          and (:toWarehouseId   is null or t.toWarehouse.id   = :toWarehouseId)
        order by t.createdAt desc, t.id desc
    """)
    Page<InventoryTransfer> search(
            @Param("keyword") String keyword,
            @Param("status") InventoryTransfer.Status status,
            @Param("fromDate") LocalDateTime fromDate,
            @Param("toDate") LocalDateTime toDate,
            @Param("fromWarehouseId") Integer fromWarehouseId,
            @Param("toWarehouseId") Integer toWarehouseId,
            Pageable pageable
    );
}
