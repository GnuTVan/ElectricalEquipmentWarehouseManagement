package com.eewms.exception;

public class NoIssueableStockException extends RuntimeException {
    public NoIssueableStockException(String message) { super(message); }
}