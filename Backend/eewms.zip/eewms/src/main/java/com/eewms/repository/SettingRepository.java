package com.eewms.repository;

import com.eewms.dto.SettingDTO;
import com.eewms.entities.Setting;
import com.eewms.constant.SettingType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SettingRepository extends JpaRepository<Setting, Integer> {
    boolean existsByTypeAndNameIgnoreCase(SettingType type, String name);
    boolean existsByTypeAndNameIgnoreCaseAndIdNot(SettingType type, String name, Integer id);

    List<Setting> findByType(SettingType type);

    //lọc theo type và status active
    List<Setting> findByTypeAndStatus(SettingType type, Setting.SettingStatus status);

}
