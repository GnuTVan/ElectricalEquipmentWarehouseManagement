package com.eewms.constant;
public enum ReturnSettlementOption {
    OFFSET_THEN_REPLACE,   // Trừ công nợ trước, còn dư thì đổi hàng
    REPLACE_ONLY           // Chỉ đổi hàng, KHÔNG trừ công nợ
}