package com.eewms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ElectricalEquipmentWarehouseManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(ElectricalEquipmentWarehouseManagementApplication.class, args);
	}

}
